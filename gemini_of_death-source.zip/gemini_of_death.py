from __future__ import annotations

import sys
import os
import json
import time
import threading
import re
import base64
import mimetypes
import webbrowser
from pathlib import Path
from datetime import datetime

# --- PyQt6 Imports ---
from PyQt6.QtCore import (
    Qt, QThread, pyqtSignal, QTimer, QSize, QPropertyAnimation,
    QEasingCurve, pyqtProperty, QRect
)
from PyQt6.QtGui import (
    QColor, QFont, QPainter, QPixmap, QTextCursor, QSyntaxHighlighter,
    QTextCharFormat, QIcon, QKeySequence, QShortcut, QPalette,
    QLinearGradient, QBrush, QFontMetrics, QTextOption
)
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTextEdit, QLineEdit, QPushButton, QLabel, QSplashScreen,
    QScrollArea, QFrame, QSizePolicy, QDialog, QFormLayout,
    QDialogButtonBox, QComboBox, QMessageBox, QSplitter,
    QToolButton, QMenu, QMenuBar, QStatusBar, QProgressBar,
    QCheckBox, QSpinBox, QDoubleSpinBox, QFileDialog, QListWidget, QListWidgetItem,
    QTabWidget, QPlainTextEdit, QScrollBar
)

# --- Try to import google-genai ---
try:
    from google import genai
    from google.genai import types
    GEMINI_AVAILABLE = True
except ImportError:
    GEMINI_AVAILABLE = False

# =============================================================================
# Constants
# =============================================================================

APP_NAME = "Gemini of Death"
ORG_NAME = "Death's Head Software"
VERSION = "1.0.0"
CONFIG_FILE   = Path.home() / ".gemini_of_death" / "config.json"
SESSIONS_DIR  = Path.home() / ".gemini_of_death" / "sessions"
PROMPTS_FILE  = Path.home() / ".gemini_of_death" / "prompts.json"
AUTOSAVE_FILE = Path.home() / ".gemini_of_death" / "autosave.json"
MEMORY_FILE   = Path.home() / ".gemini_of_death" / "memory.md"

# Approximate pricing per million tokens (as of August 2026)
TOKEN_PRICING = {
    "gemini-2.5-pro":        {"input": 1.25, "output": 10.00},
    "gemini-2.5-flash":      {"input": 0.30, "output": 2.50},
    "gemini-2.5-flash-lite": {"input": 0.10, "output": 0.40},
}

MODELS = {
    "gemini-2.5-flash": "Gemini 2.5 Flash (Recommended)",
    "gemini-2.5-flash-lite": "Gemini 2.5 Flash Lite (Fast & Cheap)",
    "gemini-2.5-pro": "Gemini 2.5 Pro (Most Powerful)",
}

DEFAULT_SYSTEM_PROMPT = """You are an expert software engineer and coding assistant integrated into 'Gemini of Death' by Death's Head Software. You help write, debug, review, and explain code across all languages.

Guidelines:
- Always wrap code in proper markdown code blocks with language tags (e.g. ```python)
- Be concise but thorough
- Point out potential bugs, edge cases, and improvements proactively
- When debugging, explain the root cause clearly
- Prefer modern, idiomatic solutions
- If asked to write a full file/module, produce complete, runnable code

CRITICAL RULES — follow these without exception:
- When writing any code file or module, ALWAYS output the COMPLETE file in a SINGLE code block. Never split code across multiple blocks or stop partway through. Never say "continued below" or ask to continue.
- If the code is long, that is fine — write every single line from top to bottom in one block.
- Always wrap code in proper markdown fenced blocks with language tags: ```python ... ```
- Never truncate, summarise, or omit any part of the code. Incomplete code is useless.
- Only use multiple code blocks if the user explicitly asks for separate files.
- Be concise in explanations but complete in code.
- Prefer modern, idiomatic solutions.
- Point out potential bugs and edge cases proactively.
"""

FILE_MODE_SYSTEM_PROMPT = """You are a code generation engine. Output ONLY a single fenced code block. Nothing else.

RULES — no exceptions:
- Your entire response must be ONE fenced code block and nothing else.
- No introduction. No explanation. No comments before or after the block.
- The very first character of your response must be the opening fence: ```
- The very last character of your response must be the closing fence: ```
- Write the COMPLETE file — every single line — inside that one block.
- Never stop early. Never truncate. Never ask to continue.
- If the file is 3000 lines, write all 3000 lines.
"""

COLORS = {
    "bg_darkest":   "#0a0a0a",
    "bg_dark":      "#111111",
    "bg_mid":       "#1a1a1a",
    "bg_panel":     "#141414",
    "bg_input":     "#0f0f0f",
    "border":       "#2a2a2a",
    "border_bright":"#3a3a3a",
    "text_primary": "#e8e8e8",
    "text_secondary":"#888888",
    "text_dim":     "#555555",
    "accent":       "#c8102e",      # Death's Head red
    "accent_dim":   "#7a0a1c",
    "accent_glow":  "#ff1a3a",
    "code_bg":      "#0d0d0d",
    "code_border":  "#252525",
    "user_bg":      "#161616",
    "assistant_bg": "#111111",
    "success":      "#2d8a4e",
    "warning":      "#c8921a",
}

STYLESHEET = f"""
QMainWindow, QDialog {{
    background-color: {COLORS['bg_dark']};
    color: {COLORS['text_primary']};
}}
QWidget {{
    background-color: transparent;
    color: {COLORS['text_primary']};
    font-family: 'Courier New', Courier, monospace;
}}
QMenuBar {{
    background-color: {COLORS['bg_darkest']};
    color: {COLORS['text_primary']};
    border-bottom: 1px solid {COLORS['border']};
    font-family: 'Courier New', Courier, monospace;
    font-size: 12px;
    padding: 2px;
}}
QMenuBar::item:selected {{
    background-color: {COLORS['accent_dim']};
    color: {COLORS['text_primary']};
}}
QMenu {{
    background-color: {COLORS['bg_mid']};
    color: {COLORS['text_primary']};
    border: 1px solid {COLORS['border_bright']};
    font-family: 'Courier New', Courier, monospace;
    font-size: 12px;
}}
QMenu::item:selected {{
    background-color: {COLORS['accent_dim']};
}}
QMenu::separator {{
    height: 1px;
    background: {COLORS['border']};
    margin: 4px 0;
}}
QStatusBar {{
    background-color: {COLORS['bg_darkest']};
    color: {COLORS['text_dim']};
    border-top: 1px solid {COLORS['border']};
    font-family: 'Courier New', Courier, monospace;
    font-size: 11px;
}}
QScrollBar:vertical {{
    background: {COLORS['bg_darkest']};
    width: 8px;
    border: none;
}}
QScrollBar::handle:vertical {{
    background: {COLORS['border_bright']};
    border-radius: 4px;
    min-height: 20px;
}}
QScrollBar::handle:vertical:hover {{
    background: {COLORS['accent']};
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0;
}}
QScrollBar:horizontal {{
    background: {COLORS['bg_darkest']};
    height: 8px;
    border: none;
}}
QScrollBar::handle:horizontal {{
    background: {COLORS['border_bright']};
    border-radius: 4px;
}}
QScrollBar::handle:horizontal:hover {{
    background: {COLORS['accent']};
}}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{
    width: 0;
}}
QPushButton {{
    background-color: {COLORS['bg_mid']};
    color: {COLORS['text_primary']};
    border: 1px solid {COLORS['border_bright']};
    padding: 6px 14px;
    font-family: 'Courier New', Courier, monospace;
    font-size: 12px;
    font-weight: bold;
}}
QPushButton:hover {{
    background-color: {COLORS['accent_dim']};
    border-color: {COLORS['accent']};
    color: #ffffff;
}}
QPushButton:pressed {{
    background-color: {COLORS['accent']};
}}
QPushButton:disabled {{
    color: {COLORS['text_dim']};
    border-color: {COLORS['border']};
    background-color: {COLORS['bg_dark']};
}}
QPushButton#header_btn {{
    background: transparent;
    color: {COLORS['text_primary']};
    border: 1px solid {COLORS['border']};
    font-size: 10px;
    font-family: 'Courier New', Courier, monospace;
    padding: 2px 8px;
    min-height: 22px;
    max-height: 22px;
}}
QPushButton#header_btn:hover {{
    color: #ffffff;
    border-color: {COLORS['accent']};
}}
QPushButton#send_btn {{
    background-color: {COLORS['accent_dim']};
    border-color: {COLORS['accent']};
    color: #ffffff;
    padding: 8px 20px;
    font-size: 13px;
}}
QPushButton#send_btn:hover {{
    background-color: {COLORS['accent']};
    border-color: {COLORS['accent_glow']};
}}
QPushButton#send_btn:disabled {{
    background-color: {COLORS['bg_mid']};
    border-color: {COLORS['border']};
    color: {COLORS['text_dim']};
}}
QTextEdit, QPlainTextEdit {{
    background-color: {COLORS['bg_input']};
    color: {COLORS['text_primary']};
    border: 1px solid {COLORS['border']};
    font-family: 'Courier New', Courier, monospace;
    font-size: 13px;
    selection-background-color: {COLORS['accent_dim']};
}}
QTextEdit:focus, QPlainTextEdit:focus {{
    border-color: {COLORS['accent']};
}}
QLineEdit {{
    background-color: {COLORS['bg_input']};
    color: {COLORS['text_primary']};
    border: 1px solid {COLORS['border']};
    padding: 6px 10px;
    font-family: 'Courier New', Courier, monospace;
    font-size: 12px;
    selection-background-color: {COLORS['accent_dim']};
}}
QLineEdit:focus {{
    border-color: {COLORS['accent']};
}}
QComboBox {{
    background-color: {COLORS['bg_mid']};
    color: {COLORS['text_primary']};
    border: 1px solid {COLORS['border_bright']};
    padding: 4px 8px;
    font-family: 'Courier New', Courier, monospace;
    font-size: 12px;
}}
QComboBox::drop-down {{
    border: none;
    width: 20px;
}}
QComboBox QAbstractItemView {{
    background-color: {COLORS['bg_mid']};
    color: {COLORS['text_primary']};
    border: 1px solid {COLORS['border_bright']};
    selection-background-color: {COLORS['accent_dim']};
    font-family: 'Courier New', Courier, monospace;
}}
QLabel {{
    color: {COLORS['text_primary']};
    font-family: 'Courier New', Courier, monospace;
}}
QFrame[frameShape="4"], QFrame[frameShape="5"] {{
    color: {COLORS['border']};
}}
QSplitter::handle {{
    background-color: {COLORS['border']};
}}
QSplitter::handle:horizontal {{
    width: 1px;
}}
QListWidget {{
    background-color: {COLORS['bg_panel']};
    color: {COLORS['text_primary']};
    border: 1px solid {COLORS['border']};
    font-family: 'Courier New', Courier, monospace;
    font-size: 11px;
}}
QListWidget::item {{
    padding: 6px 8px;
    border-bottom: 1px solid {COLORS['border']};
}}
QListWidget::item:selected {{
    background-color: {COLORS['accent_dim']};
    color: #ffffff;
}}
QListWidget::item:hover {{
    background-color: {COLORS['bg_mid']};
}}
QCheckBox {{
    font-family: 'Courier New', Courier, monospace;
    font-size: 12px;
    spacing: 8px;
}}
QCheckBox::indicator {{
    width: 14px;
    height: 14px;
    border: 1px solid {COLORS['border_bright']};
    background: {COLORS['bg_input']};
}}
QCheckBox::indicator:checked {{
    background: {COLORS['accent']};
    border-color: {COLORS['accent']};
}}
QSpinBox {{
    background-color: {COLORS['bg_input']};
    color: {COLORS['text_primary']};
    border: 1px solid {COLORS['border']};
    padding: 4px;
    font-family: 'Courier New', Courier, monospace;
    font-size: 12px;
}}
QTabWidget::pane {{
    border: 1px solid {COLORS['border']};
    background: {COLORS['bg_dark']};
}}
QTabBar::tab {{
    background: {COLORS['bg_mid']};
    color: {COLORS['text_secondary']};
    border: 1px solid {COLORS['border']};
    padding: 6px 14px;
    font-family: 'Courier New', Courier, monospace;
    font-size: 11px;
}}
QTabBar::tab:selected {{
    background: {COLORS['bg_dark']};
    color: {COLORS['text_primary']};
    border-bottom-color: {COLORS['accent']};
}}
QProgressBar {{
    background: {COLORS['bg_darkest']};
    border: 1px solid {COLORS['border']};
    height: 4px;
    text-align: center;
}}
QProgressBar::chunk {{
    background: {COLORS['accent']};
}}
"""

# =============================================================================
# Config Manager
# =============================================================================

class ConfigManager:
    def __init__(self):
        CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
        self._data = self._load()

    def _load(self):
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE) as f:
                    return json.load(f)
            except Exception:
                pass
        return {}

    def save(self):
        with open(CONFIG_FILE, "w") as f:
            json.dump(self._data, f, indent=2)

    def get(self, key, default=None):
        return self._data.get(key, default)

    def set(self, key, value):
        self._data[key] = value
        self.save()

config = ConfigManager()

# =============================================================================
# Memory Manager
# =============================================================================

class MemoryManager:
    """Manages persistent memory across sessions via a local markdown file."""

    DEFAULT_MEMORY = """# Gemini of Death — Persistent Memory

This file is injected into every conversation as context.
Edit it manually or use Settings > Memory > Auto-Update to generate from a session.
Keep it concise — every line costs tokens.

## User Preferences
<!-- Add your coding style preferences, language choices, etc. -->

## Project Context
<!-- Notes about ongoing projects, tech stacks, conventions. -->

## Notes
<!-- Anything else Gemini should always know. -->
"""

    def load(self) -> str:
        if MEMORY_FILE.exists():
            try:
                return MEMORY_FILE.read_text(encoding="utf-8").strip()
            except Exception:
                pass
        return ""

    def save(self, content: str):
        MEMORY_FILE.parent.mkdir(parents=True, exist_ok=True)
        MEMORY_FILE.write_text(content, encoding="utf-8")

    def inject(self, system_prompt: str) -> str:
        """Prepend memory to a system prompt if memory file has content."""
        memory = self.load()
        if not memory:
            return system_prompt
        return f"--- PERSISTENT MEMORY ---\n{memory}\n--- END MEMORY ---\n\n{system_prompt}"

    def create_default(self):
        if not MEMORY_FILE.exists():
            self.save(self.DEFAULT_MEMORY)


memory_manager = MemoryManager()
memory_manager.create_default()

# =============================================================================
# Splash Screen
# =============================================================================

def create_splash():
    try:
        splash_path = Path(__file__).parent / "splash.png"
        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(10, 10, 10))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(800, 600, Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
        else:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(10, 10, 10))

        painter = QPainter(pixmap)
        # Top title — white
        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Courier New", 36, QFont.Weight.Bold))
        text_rect = pixmap.rect()
        text_rect.setTop(30); text_rect.setBottom(130)
        painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)

        if not splash_path.exists():
            # ASCII skull fallback
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier New", 13))
            skull_art = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            y_start = 220
            for i, line in enumerate(skull_art):
                painter.drawText(250, y_start + (i * 26), line)

        # Footer — white
        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Courier New", 14, QFont.Weight.Bold))
        footer_rect = pixmap.rect()
        footer_rect.setTop(pixmap.height() - 70)
        footer_rect.setBottom(pixmap.height() - 30)
        painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)

        painter.end()
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None

# =============================================================================
# Syntax Highlighter
# =============================================================================

class CodeHighlighter(QSyntaxHighlighter):
    """Basic syntax highlighter for code blocks in the chat."""

    KEYWORDS = {
        'python': ['def', 'class', 'import', 'from', 'return', 'if', 'elif', 'else',
                   'for', 'while', 'try', 'except', 'finally', 'with', 'as', 'in',
                   'not', 'and', 'or', 'is', 'None', 'True', 'False', 'pass', 'break',
                   'continue', 'lambda', 'yield', 'async', 'await', 'raise', 'del',
                   'global', 'nonlocal', 'assert', 'print', 'self'],
        'javascript': ['function', 'const', 'let', 'var', 'return', 'if', 'else',
                       'for', 'while', 'class', 'import', 'export', 'from', 'async',
                       'await', 'new', 'this', 'null', 'undefined', 'true', 'false',
                       'try', 'catch', 'finally', 'throw', 'typeof', 'instanceof'],
    }

    def __init__(self, parent):
        super().__init__(parent)
        self._rules = []
        self._setup_rules()

    def _fmt(self, color, bold=False, italic=False):
        fmt = QTextCharFormat()
        fmt.setForeground(QColor(color))
        if bold:
            fmt.setFontWeight(QFont.Weight.Bold)
        if italic:
            fmt.setFontItalic(True)
        return fmt

    def _setup_rules(self):
        kw_fmt = self._fmt("#c792ea", bold=True)
        all_kw = set()
        for kws in self.KEYWORDS.values():
            all_kw.update(kws)
        for kw in all_kw:
            self._rules.append((re.compile(rf'\b{kw}\b'), kw_fmt))

        # Strings
        self._rules.append((re.compile(r'"[^"\\]*(\\.[^"\\]*)*"'), self._fmt("#c3e88d")))
        self._rules.append((re.compile(r"'[^'\\]*(\\.[^'\\]*)*'"), self._fmt("#c3e88d")))
        self._rules.append((re.compile(r'`[^`]*`'), self._fmt("#c3e88d")))

        # Numbers
        self._rules.append((re.compile(r'\b\d+\.?\d*\b'), self._fmt("#f78c6c")))

        # Comments
        self._rules.append((re.compile(r'#[^\n]*'), self._fmt("#546e7a", italic=True)))
        self._rules.append((re.compile(r'//[^\n]*'), self._fmt("#546e7a", italic=True)))

        # Functions
        self._rules.append((re.compile(r'\b\w+(?=\()'), self._fmt("#82aaff")))

        # Code fence markers
        self._rules.append((re.compile(r'^```\w*$'), self._fmt("#c8102e", bold=True)))

    def highlightBlock(self, text):
        for pattern, fmt in self._rules:
            for m in pattern.finditer(text):
                self.setFormat(m.start(), m.end() - m.start(), fmt)

# =============================================================================
# API Worker Thread
# =============================================================================

class APIWorker(QThread):
    chunk_received = pyqtSignal(str)
    finished = pyqtSignal(int, int)   # input_tokens, output_tokens
    error = pyqtSignal(str)

    def __init__(self, api_key, model, messages, system_prompt, max_tokens, temperature):
        super().__init__()
        self.api_key = api_key
        self.model = model
        self.messages = messages
        self.system_prompt = system_prompt
        self.max_tokens = max_tokens
        self.temperature = temperature
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def _convert_messages(self):
        """Convert internal message dicts into a Gemini Content list."""
        contents = []
        for m in self.messages:
            role = "user" if m["role"] == "user" else "model"
            content = m["content"]
            parts = []
            if isinstance(content, str):
                if content:
                    parts.append(types.Part.from_text(text=content))
            elif isinstance(content, list):
                for block in content:
                    if not isinstance(block, dict):
                        continue
                    btype = block.get("type")
                    if btype == "text":
                        txt = block.get("text", "")
                        if txt:
                            parts.append(types.Part.from_text(text=txt))
                    elif btype == "image":
                        src = block.get("source", {})
                        if src.get("type") == "base64":
                            try:
                                data = base64.b64decode(src.get("data", ""))
                                mime = src.get("media_type", "image/png")
                                parts.append(types.Part.from_bytes(data=data, mime_type=mime))
                            except Exception:
                                pass
            if parts:
                contents.append(types.Content(role=role, parts=parts))
        return contents

    def run(self):
        try:
            client = genai.Client(api_key=self.api_key)
            contents = self._convert_messages()
            cfg = types.GenerateContentConfig(
                system_instruction=self.system_prompt,
                max_output_tokens=self.max_tokens,
                temperature=self.temperature,
            )
            input_tok = 0
            output_tok = 0
            stream = client.models.generate_content_stream(
                model=self.model,
                contents=contents,
                config=cfg,
            )
            for chunk in stream:
                if self._cancelled:
                    break
                text = getattr(chunk, "text", None)
                if text:
                    self.chunk_received.emit(text)
                usage = getattr(chunk, "usage_metadata", None)
                if usage:
                    pt = getattr(usage, "prompt_token_count", None)
                    ct = getattr(usage, "candidates_token_count", None)
                    if pt:
                        input_tok = pt
                    if ct:
                        output_tok = ct
            self.finished.emit(input_tok or 0, output_tok or 0)
        except Exception as e:
            self.error.emit(str(e))

# =============================================================================
# Code Block Extraction
# =============================================================================

# Maps common language tags to file extensions
LANG_TO_EXT = {
    "python": ".py", "py": ".py",
    "javascript": ".js", "js": ".js",
    "typescript": ".ts", "ts": ".ts",
    "jsx": ".jsx", "tsx": ".tsx",
    "html": ".html", "css": ".css",
    "json": ".json", "yaml": ".yaml", "yml": ".yml",
    "toml": ".toml", "xml": ".xml",
    "bash": ".sh", "sh": ".sh", "shell": ".sh",
    "zsh": ".zsh", "fish": ".fish",
    "c": ".c", "cpp": ".cpp", "cxx": ".cpp",
    "h": ".h", "hpp": ".hpp",
    "cs": ".cs", "java": ".java",
    "go": ".go", "rust": ".rs", "rs": ".rs",
    "ruby": ".rb", "rb": ".rb",
    "php": ".php", "swift": ".swift",
    "kotlin": ".kt", "scala": ".scala",
    "r": ".r", "sql": ".sql",
    "markdown": ".md", "md": ".md",
    "dockerfile": "", "makefile": "",
    "powershell": ".ps1", "ps1": ".ps1",
    "bat": ".bat", "cmd": ".bat",
    "lua": ".lua", "perl": ".pl",
    "asm": ".asm", "assembly": ".asm",
    "ini": ".ini", "cfg": ".cfg",
    "text": ".txt", "txt": ".txt",
    "": ".txt",
}

def _make_block(lang: str, code: str, counts: dict) -> dict:
    ext = LANG_TO_EXT.get(lang, f".{lang}" if lang else ".txt")
    counts[lang] = counts.get(lang, 0) + 1
    n = counts[lang]
    if lang == "dockerfile":
        name = "Dockerfile" if n == 1 else f"Dockerfile_{n}"
    elif lang == "makefile":
        name = "Makefile" if n == 1 else f"Makefile_{n}"
    else:
        base = lang if lang else "code"
        name = f"{base}_{n}{ext}"
    return {"lang": lang, "code": code, "suggested_name": name}


def extract_code_blocks(text: str) -> list[dict]:
    """
    Extract all fenced code blocks from markdown text.
    Handles CRLF, unclosed fences, and varied whitespace.
    Returns list of dicts: {lang, code, suggested_name}
    """
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    blocks = []
    counts = {}

    # Primary: match properly closed fences (multiline anchored)
    pattern = re.compile(r'^```(\w*)[^\n]*\n(.*?)^```', re.DOTALL | re.MULTILINE)
    for m in pattern.finditer(text):
        lang = m.group(1).strip().lower()
        code = m.group(2)
        blocks.append(_make_block(lang, code, counts))

    # Fallback: unclosed fence (response cut off mid-stream or token limit hit)
    if not blocks:
        unclosed = re.compile(r'^```(\w*)[^\n]*\n(.*?)(?:^```|\Z)', re.DOTALL | re.MULTILINE)
        for m in unclosed.finditer(text):
            lang = m.group(1).strip().lower()
            code = m.group(2).rstrip('`').strip()
            if code:
                blocks.append(_make_block(lang, code, counts))

    return blocks


# =============================================================================
# Save Files Dialog
# =============================================================================

class SaveFilesDialog(QDialog):
    """Shows detected code blocks and lets the user rename + save them."""

    def __init__(self, blocks: list[dict], parent=None):
        super().__init__(parent)
        self.blocks = blocks
        self.setWindowTitle(f"Save Generated Files — {APP_NAME}")
        self.setMinimumSize(620, 420)
        self.setStyleSheet(STYLESHEET)
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        layout.setContentsMargins(16, 16, 16, 16)

        title = QLabel(f"☠ {len(self.blocks)} FILE(S) DETECTED")
        title.setFont(QFont("Courier New", 13, QFont.Weight.Bold))
        title.setStyleSheet(f"color: {COLORS['accent']};")
        layout.addWidget(title)

        note = QLabel("Edit filenames below, then click Save Selected to write them to disk.")
        note.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 11px;")
        layout.addWidget(note)

        # Tabs — one per block
        self.tabs = QTabWidget()
        self.name_edits = []

        for i, block in enumerate(self.blocks):
            tab = QWidget()
            tab_layout = QVBoxLayout(tab)
            tab_layout.setContentsMargins(8, 8, 8, 8)
            tab_layout.setSpacing(6)

            # Filename row
            name_row = QHBoxLayout()
            name_lbl = QLabel("Filename:")
            name_lbl.setFixedWidth(70)
            name_row.addWidget(name_lbl)
            name_edit = QLineEdit(block["suggested_name"])
            name_edit.setFont(QFont("Courier New", 12))
            name_row.addWidget(name_edit)
            self.name_edits.append(name_edit)
            tab_layout.addLayout(name_row)

            # Code preview
            preview = QPlainTextEdit()
            preview.setPlainText(block["code"])
            preview.setReadOnly(True)
            preview.setFont(QFont("Courier New", 11))
            preview.setStyleSheet(f"""
                QPlainTextEdit {{
                    background: {COLORS['code_bg']};
                    color: {COLORS['text_primary']};
                    border: 1px solid {COLORS['code_border']};
                }}
            """)
            tab_layout.addWidget(preview)

            lang = block["lang"] or "text"
            self.tabs.addTab(tab, f"{lang}_{i+1}")

        layout.addWidget(self.tabs)

        # Buttons
        btn_row = QHBoxLayout()
        btn_row.addStretch()

        save_all_btn = QPushButton("☠ Save All")
        save_all_btn.setObjectName("send_btn")
        save_all_btn.clicked.connect(self._save_all)
        btn_row.addWidget(save_all_btn)

        save_sel_btn = QPushButton("Save Current Tab")
        save_sel_btn.clicked.connect(self._save_current)
        btn_row.addWidget(save_sel_btn)

        cancel_btn = QPushButton("Cancel")
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(cancel_btn)

        layout.addLayout(btn_row)

    def _save_one(self, index: int) -> bool:
        name = self.name_edits[index].text().strip()
        if not name:
            QMessageBox.warning(self, "Invalid Name", "Filename cannot be empty.")
            return False
        path, _ = QFileDialog.getSaveFileName(self, "Save File", name)
        if not path:
            return False
        try:
            Path(path).write_text(self.blocks[index]["code"], encoding="utf-8")
            return True
        except Exception as e:
            QMessageBox.critical(self, "Save Error", str(e))
            return False

    def _save_current(self):
        self._save_one(self.tabs.currentIndex())

    def _save_all(self):
        # Ask for a directory then save all with their suggested names
        folder = QFileDialog.getExistingDirectory(self, "Select Folder to Save All Files")
        if not folder:
            return
        saved = []
        errors = []
        for i, block in enumerate(self.blocks):
            name = self.name_edits[i].text().strip() or block["suggested_name"]
            dest = Path(folder) / name
            try:
                dest.write_text(block["code"], encoding="utf-8")
                saved.append(name)
            except Exception as e:
                errors.append(f"{name}: {e}")
        msg = f"Saved {len(saved)} file(s) to:\n{folder}"
        if errors:
            msg += f"\n\nErrors:\n" + "\n".join(errors)
        QMessageBox.information(self, "Files Saved", msg)
        self.accept()


# =============================================================================
# Message Bubble Widget
# =============================================================================

class MessageWidget(QFrame):
    use_code = pyqtSignal(str)  # emits code block content to load into input

    def __init__(self, role: str, content: str, parent=None):
        super().__init__(parent)
        self.role = role
        self.content = content
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(6)

        # Header row — fixed height container so buttons are never clipped
        header_widget = QWidget()
        header_widget.setFixedHeight(28)
        header_widget.setStyleSheet("background: transparent;")
        header = QHBoxLayout(header_widget)
        header.setContentsMargins(0, 0, 0, 0)
        header.setSpacing(6)
        role_label = QLabel("▶ YOU" if self.role == "user" else f"☠ {APP_NAME.upper()}")
        role_label.setFont(QFont("Courier New", 10, QFont.Weight.Bold))
        role_label.setStyleSheet(
            f"color: {COLORS['text_secondary']};" if self.role == "user"
            else f"color: {COLORS['accent']};"
        )
        header.addWidget(role_label)
        header.addStretch()

        # USE and SAVE CODE buttons — assistant messages only
        if self.role == "assistant":
            self.use_btn = QPushButton("USE CODE")
            self.use_btn.setObjectName("header_btn")
            self.use_btn.clicked.connect(self._use_code)
            header.addWidget(self.use_btn)

            self.save_code_btn = QPushButton("SAVE CODE")
            self.save_code_btn.setObjectName("header_btn")
            self.save_code_btn.clicked.connect(self._save_code)
            header.addWidget(self.save_code_btn)

        # Copy button
        self.copy_btn = QPushButton("COPY")
        self.copy_btn.setObjectName("header_btn")
        self.copy_btn.clicked.connect(self._copy)
        header.addWidget(self.copy_btn)
        layout.addWidget(header_widget)

        # Single plain-text content area — simple and reliable
        self.content_edit = QTextEdit()
        self.content_edit.setReadOnly(True)
        self.content_edit.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.content_edit.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.content_edit.setFrameShape(QFrame.Shape.NoFrame)
        self.content_edit.setFont(QFont("Courier New", 12))
        self.content_edit.setWordWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere)
        self.content_edit.setStyleSheet(f"""
            QTextEdit {{
                background-color: {'#161616' if self.role == 'user' else COLORS['assistant_bg']};
                color: {COLORS['text_primary']};
                border: none;
                padding: 4px;
            }}
        """)
        CodeHighlighter(self.content_edit.document())
        layout.addWidget(self.content_edit)

        if self.role == "user":
            self.setStyleSheet(f"""
                MessageWidget {{
                    background-color: {COLORS['user_bg']};
                    border-left: 2px solid {COLORS['border_bright']};
                    margin: 2px 0px;
                }}
            """)
        else:
            self.setStyleSheet(f"""
                MessageWidget {{
                    background-color: {COLORS['assistant_bg']};
                    border-left: 2px solid {COLORS['accent']};
                    margin: 2px 0px;
                }}
            """)

        self.set_content(self.content)

    def _use_code(self):
        """Extract code blocks and emit for loading into input box."""
        blocks = extract_code_blocks(self.content)
        if blocks:
            code = "\n\n".join(b["code"].strip() for b in blocks)
        else:
            code = self.content.strip()
        self.use_code.emit(code)

    def _save_code(self):
        """Extract code and save directly to a file — no markdown, no explanation."""
        blocks = extract_code_blocks(self.content)
        if blocks:
            code = blocks[0]["code"].strip()
            suggested = blocks[0]["suggested_name"]
        else:
            # No fenced block — save raw content
            code = self.content.strip()
            suggested = "output.txt"

        path, _ = QFileDialog.getSaveFileName(
            self, "Save Code", suggested, "All Files (*)"
        )
        if path:
            try:
                Path(path).write_text(code, encoding="utf-8")
            except Exception as e:
                QMessageBox.critical(self, "Save Error", str(e))
            # If multiple blocks, join them all
            code = "\n\n".join(b["code"].strip() for b in blocks)
        else:
            # No fenced blocks — use the raw content
            code = self.content.strip()
        self.use_code.emit(code)

    def _copy(self):
        text = self.content_edit.toPlainText()
        QApplication.clipboard().setText(text)
        self.copy_btn.setText("COPIED!")
        QTimer.singleShot(1500, self._reset_copy_btn)

    def _reset_copy_btn(self):
        self.copy_btn.setText("COPY")

    def set_content(self, text):
        # content may be a list of blocks (when files were attached)
        if isinstance(text, list):
            parts = []
            for block in text:
                if isinstance(block, dict):
                    if block.get("type") == "text":
                        parts.append(block.get("text", ""))
                    elif block.get("type") == "image":
                        parts.append("[image attachment]")
                    else:
                        parts.append(f"[{block.get('type', 'attachment')}]")
            text = "\n".join(parts)
        self.content = text or ""
        self.content_edit.setPlainText(self.content)
        self._adjust_height()

    def append_content(self, chunk: str):
        self.content += chunk
        self.content_edit.setPlainText(self.content)
        cursor = self.content_edit.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        self.content_edit.setTextCursor(cursor)
        self._adjust_height()

    def render_blocks(self):
        pass  # no-op — kept for call-site compatibility

    def _adjust_height(self):
        doc = self.content_edit.document()
        doc.setTextWidth(self.content_edit.viewport().width() or 800)
        h = int(doc.size().height()) + 24
        h = max(40, h)  # no upper cap — expand to full content height
        self.content_edit.setFixedHeight(h)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._adjust_height()

# =============================================================================
# Response Save Dialog
# =============================================================================

class ResponseSaveDialog(QDialog):
    """
    Shows the full raw response and any extracted code blocks.
    User can save the whole response or individual blocks to actual files.
    """
    def __init__(self, content: str, parent=None):
        super().__init__(parent)
        self.content = content
        self.blocks = extract_code_blocks(content)
        self.setWindowTitle(f"Save Response — {APP_NAME}")
        self.setMinimumSize(740, 560)
        self.setStyleSheet(STYLESHEET)
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        title = QLabel(f"☠ SAVE RESPONSE  —  {len(self.blocks)} code block(s) detected")
        title.setFont(QFont("Courier New", 13, QFont.Weight.Bold))
        title.setStyleSheet(f"color: {COLORS['accent']};")
        layout.addWidget(title)

        tabs = QTabWidget()
        layout.addWidget(tabs, 1)

        # --- Tab 1: Full raw response ---
        full_tab = QWidget()
        full_layout = QVBoxLayout(full_tab)
        full_layout.setContentsMargins(8, 8, 8, 8)
        full_layout.setSpacing(6)

        note = QLabel("The complete response exactly as received. Save as .md, .txt, or any extension.")
        note.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 11px;")
        full_layout.addWidget(note)

        full_preview = QPlainTextEdit()
        full_preview.setPlainText(self.content)
        full_preview.setReadOnly(True)
        full_preview.setFont(QFont("Courier New", 11))
        full_preview.setStyleSheet(f"""
            QPlainTextEdit {{
                background: {COLORS['code_bg']};
                color: {COLORS['text_primary']};
                border: 1px solid {COLORS['code_border']};
            }}
        """)
        full_layout.addWidget(full_preview)

        save_full_btn = QPushButton("☠ Save Full Response As...")
        save_full_btn.setObjectName("send_btn")
        save_full_btn.setFixedHeight(36)
        save_full_btn.clicked.connect(self._save_full)
        full_layout.addWidget(save_full_btn)

        tabs.addTab(full_tab, "Full Response")

        # --- Tabs for each code block ---
        for i, block in enumerate(self.blocks):
            tab = QWidget()
            tab_layout = QVBoxLayout(tab)
            tab_layout.setContentsMargins(8, 8, 8, 8)
            tab_layout.setSpacing(6)

            name_row = QHBoxLayout()
            name_lbl = QLabel("Save as:")
            name_lbl.setFixedWidth(60)
            name_row.addWidget(name_lbl)
            name_edit = QLineEdit(block["suggested_name"])
            name_edit.setFont(QFont("Courier New", 11))
            name_row.addWidget(name_edit)
            block["_name_edit"] = name_edit  # store ref
            tab_layout.addLayout(name_row)

            preview = QPlainTextEdit()
            preview.setPlainText(block["code"])
            preview.setReadOnly(True)
            preview.setFont(QFont("Courier New", 11))
            preview.setStyleSheet(f"""
                QPlainTextEdit {{
                    background: {COLORS['code_bg']};
                    color: {COLORS['text_primary']};
                    border: 1px solid {COLORS['code_border']};
                }}
            """)
            tab_layout.addWidget(preview)

            save_btn = QPushButton(f"☠ Save Block As...")
            save_btn.setObjectName("send_btn")
            save_btn.setFixedHeight(36)
            save_btn.clicked.connect(lambda checked, idx=i: self._save_block(idx))
            tab_layout.addWidget(save_btn)

            lang = block["lang"] or "code"
            tabs.addTab(tab, f"{lang} [{i+1}]")

        # Save all blocks button
        if self.blocks:
            save_all_btn = QPushButton(f"Save All {len(self.blocks)} Block(s) to Folder...")
            save_all_btn.setFixedHeight(32)
            save_all_btn.clicked.connect(self._save_all_blocks)
            layout.addWidget(save_all_btn)

        close_btn = QPushButton("Close")
        close_btn.setFixedHeight(32)
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)

    def _save_full(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Full Response",
            "response.md",
            "Markdown (*.md);;Text (*.txt);;All Files (*)"
        )
        if path:
            try:
                Path(path).write_text(self.content, encoding="utf-8")
                QMessageBox.information(self, "Saved", f"Response saved to:\n{path}")
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    def _save_block(self, idx: int):
        block = self.blocks[idx]
        suggested = block["_name_edit"].text().strip() or block["suggested_name"]
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Code Block", suggested, "All Files (*)"
        )
        if path:
            try:
                Path(path).write_text(block["code"], encoding="utf-8")
                QMessageBox.information(self, "Saved", f"Saved to:\n{path}")
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    def _save_all_blocks(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Folder for All Blocks")
        if not folder:
            return
        saved, errors = [], []
        for block in self.blocks:
            name = block["_name_edit"].text().strip() or block["suggested_name"]
            dest = Path(folder) / name
            try:
                dest.write_text(block["code"], encoding="utf-8")
                saved.append(name)
            except Exception as e:
                errors.append(f"{name}: {e}")
        msg = f"Saved {len(saved)} file(s) to:\n{folder}"
        if errors:
            msg += "\n\nErrors:\n" + "\n".join(errors)
        QMessageBox.information(self, "Done", msg)


# =============================================================================
# Prompt Library
# =============================================================================

DEFAULT_PROMPTS = [
    {"name": "Code Review",      "prompt": "Please review the following code for bugs, security issues, performance problems, and style. Be thorough and specific."},
    {"name": "Debug Help",       "prompt": "Help me debug this issue. Explain the root cause clearly and provide a fix with explanation."},
    {"name": "Explain Code",     "prompt": "Explain this code in plain English. Cover what it does, how it works, and any important patterns used."},
    {"name": "Write Tests",      "prompt": "Write comprehensive unit tests for this code. Cover happy paths, edge cases, and error conditions."},
    {"name": "Refactor",         "prompt": "Refactor this code for clarity, maintainability, and best practices. Explain each change you make."},
    {"name": "Architecture",     "prompt": "Help me design the architecture for this. Consider scalability, maintainability, and separation of concerns."},
    {"name": "Optimise",         "prompt": "Optimise this code for performance. Profile mentally, identify bottlenecks, and suggest improvements with explanation."},
    {"name": "Document",         "prompt": "Write clear, comprehensive documentation for this code including docstrings, comments, and a README section."},
]

class PromptLibraryDialog(QDialog):
    prompt_selected = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Prompt Library — {APP_NAME}")
        self.setMinimumSize(640, 480)
        self.setStyleSheet(STYLESHEET)
        self._prompts = self._load()
        self._setup_ui()

    def _load(self) -> list[dict]:
        if PROMPTS_FILE.exists():
            try:
                return json.loads(PROMPTS_FILE.read_text())
            except Exception:
                pass
        return list(DEFAULT_PROMPTS)

    def _save(self):
        PROMPTS_FILE.parent.mkdir(parents=True, exist_ok=True)
        PROMPTS_FILE.write_text(json.dumps(self._prompts, indent=2))

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        title = QLabel("☠ PROMPT LIBRARY")
        title.setFont(QFont("Courier New", 14, QFont.Weight.Bold))
        title.setStyleSheet(f"color: {COLORS['accent']};")
        layout.addWidget(title)

        note = QLabel("Double-click a prompt to insert it into the input box. Edit and save your own.")
        note.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 11px;")
        layout.addWidget(note)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        # List
        self.list_widget = QListWidget()
        self.list_widget.currentRowChanged.connect(self._on_select)
        self.list_widget.itemDoubleClicked.connect(self._use_prompt)
        splitter.addWidget(self.list_widget)

        # Editor
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(8, 0, 0, 0)
        right_layout.setSpacing(6)

        name_row = QHBoxLayout()
        name_lbl = QLabel("Name:")
        name_lbl.setFixedWidth(50)
        name_row.addWidget(name_lbl)
        self.name_edit = QLineEdit()
        self.name_edit.setFont(QFont("Courier New", 11))
        name_row.addWidget(self.name_edit)
        right_layout.addLayout(name_row)

        self.prompt_edit = QPlainTextEdit()
        self.prompt_edit.setFont(QFont("Courier New", 11))
        self.prompt_edit.setPlaceholderText("Prompt text...")
        right_layout.addWidget(self.prompt_edit)

        btn_row = QHBoxLayout()
        use_btn = QPushButton("☠ USE")
        use_btn.setObjectName("send_btn")
        use_btn.clicked.connect(self._use_prompt)
        btn_row.addWidget(use_btn)

        save_btn = QPushButton("Save")
        save_btn.clicked.connect(self._save_current)
        btn_row.addWidget(save_btn)

        new_btn = QPushButton("New")
        new_btn.clicked.connect(self._new_prompt)
        btn_row.addWidget(new_btn)

        del_btn = QPushButton("Delete")
        del_btn.clicked.connect(self._delete_current)
        btn_row.addWidget(del_btn)

        right_layout.addLayout(btn_row)
        splitter.addWidget(right)
        splitter.setSizes([200, 420])
        layout.addWidget(splitter)

        self._refresh_list()

    def _refresh_list(self):
        self.list_widget.clear()
        for p in self._prompts:
            self.list_widget.addItem(p["name"])
        if self._prompts:
            self.list_widget.setCurrentRow(0)

    def _on_select(self, row: int):
        if 0 <= row < len(self._prompts):
            self.name_edit.setText(self._prompts[row]["name"])
            self.prompt_edit.setPlainText(self._prompts[row]["prompt"])

    def _use_prompt(self):
        row = self.list_widget.currentRow()
        if 0 <= row < len(self._prompts):
            self.prompt_selected.emit(self._prompts[row]["prompt"])
            self.accept()

    def _save_current(self):
        row = self.list_widget.currentRow()
        name = self.name_edit.text().strip()
        prompt = self.prompt_edit.toPlainText().strip()
        if not name or not prompt:
            return
        if 0 <= row < len(self._prompts):
            self._prompts[row] = {"name": name, "prompt": prompt}
        else:
            self._prompts.append({"name": name, "prompt": prompt})
        self._save()
        self._refresh_list()

    def _new_prompt(self):
        self._prompts.append({"name": "New Prompt", "prompt": ""})
        self._save()
        self._refresh_list()
        self.list_widget.setCurrentRow(len(self._prompts) - 1)
        self.name_edit.setFocus()

    def _delete_current(self):
        row = self.list_widget.currentRow()
        if 0 <= row < len(self._prompts):
            del self._prompts[row]
            self._save()
            self._refresh_list()


# =============================================================================
# Settings Dialog
# =============================================================================

class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Settings — {APP_NAME}")
        self.setMinimumWidth(560)
        self.setStyleSheet(STYLESHEET)
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(16)
        layout.setContentsMargins(20, 20, 20, 20)

        # Title
        title = QLabel("☠ CONFIGURATION")
        title.setFont(QFont("Courier New", 16, QFont.Weight.Bold))
        title.setStyleSheet(f"color: {COLORS['accent']};")
        layout.addWidget(title)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet(f"color: {COLORS['border']};")
        layout.addWidget(sep)

        tabs = QTabWidget()
        layout.addWidget(tabs)

        # --- API Tab ---
        api_tab = QWidget()
        api_layout = QFormLayout(api_tab)
        api_layout.setSpacing(12)
        api_layout.setContentsMargins(12, 12, 12, 12)

        api_note = QLabel(
            "Get your API key at: aistudio.google.com/apikey\n"
            "Stored locally in ~/.gemini_of_death/config.json"
        )
        api_note.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 11px;")
        api_note.setWordWrap(True)
        api_layout.addRow(api_note)

        self.api_key_edit = QLineEdit()
        self.api_key_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.api_key_edit.setPlaceholderText("AIza...")
        self.api_key_edit.setText(config.get("api_key", ""))
        api_layout.addRow("API Key:", self.api_key_edit)

        show_key_cb = QCheckBox("Show key")
        show_key_cb.toggled.connect(
            lambda c: self.api_key_edit.setEchoMode(
                QLineEdit.EchoMode.Normal if c else QLineEdit.EchoMode.Password
            )
        )
        api_layout.addRow("", show_key_cb)

        self.model_combo = QComboBox()
        for model_id, model_name in MODELS.items():
            self.model_combo.addItem(model_name, model_id)
        saved_model = config.get("model", "gemini-2.5-flash")
        for i in range(self.model_combo.count()):
            if self.model_combo.itemData(i) == saved_model:
                self.model_combo.setCurrentIndex(i)
                break
        api_layout.addRow("Model:", self.model_combo)

        self.max_tokens_spin = QSpinBox()
        self.max_tokens_spin.setRange(256, 65536)
        self.max_tokens_spin.setValue(config.get("max_tokens", 16000))
        self.max_tokens_spin.setSingleStep(256)
        api_layout.addRow("Max Tokens:", self.max_tokens_spin)

        self.temp_spin = QDoubleSpinBox()
        self.temp_spin.setRange(0.0, 1.0)
        self.temp_spin.setSingleStep(0.05)
        self.temp_spin.setDecimals(2)
        self.temp_spin.setValue(config.get("temperature", 0.7))
        temp_note = QLabel("0.0 = precise/deterministic  ·  1.0 = creative/varied")
        temp_note.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 10px;")
        api_layout.addRow("Temperature:", self.temp_spin)
        api_layout.addRow("", temp_note)

        tabs.addTab(api_tab, "API")

        # --- System Prompt Tab ---
        sys_tab = QWidget()
        sys_layout = QVBoxLayout(sys_tab)
        sys_layout.setContentsMargins(12, 12, 12, 12)

        sys_note = QLabel("Customize the system prompt sent with every request.")
        sys_note.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 11px;")
        sys_layout.addWidget(sys_note)

        self.system_prompt_edit = QPlainTextEdit()
        self.system_prompt_edit.setPlainText(config.get("system_prompt", DEFAULT_SYSTEM_PROMPT))
        self.system_prompt_edit.setFont(QFont("Courier New", 11))
        sys_layout.addWidget(self.system_prompt_edit)

        reset_btn = QPushButton("Reset to Default")
        reset_btn.clicked.connect(lambda: self.system_prompt_edit.setPlainText(DEFAULT_SYSTEM_PROMPT))
        sys_layout.addWidget(reset_btn)

        tabs.addTab(sys_tab, "System Prompt")

        # --- Memory Tab ---
        mem_tab = QWidget()
        mem_layout = QVBoxLayout(mem_tab)
        mem_layout.setContentsMargins(12, 12, 12, 12)
        mem_layout.setSpacing(8)

        mem_note = QLabel(
            "Memory is injected into every conversation as context.\n"
            f"Stored at: {MEMORY_FILE}\n"
            "Keep it concise — every line costs tokens on every request."
        )
        mem_note.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 11px;")
        mem_note.setWordWrap(True)
        mem_layout.addWidget(mem_note)

        self.memory_edit = QPlainTextEdit()
        self.memory_edit.setPlainText(memory_manager.load())
        self.memory_edit.setFont(QFont("Courier New", 11))
        self.memory_edit.setPlaceholderText("Memory is empty. Add notes here or use Auto-Update.")
        mem_layout.addWidget(self.memory_edit)

        mem_btn_row = QHBoxLayout()

        auto_update_btn = QPushButton("☠ Auto-Update from Current Session")
        auto_update_btn.setToolTip("Ask Gemini Flash Lite to summarise the current session and update memory")
        auto_update_btn.clicked.connect(self._auto_update_memory)
        mem_btn_row.addWidget(auto_update_btn)

        clear_mem_btn = QPushButton("Clear Memory")
        clear_mem_btn.clicked.connect(lambda: self.memory_edit.setPlainText(""))
        mem_btn_row.addWidget(clear_mem_btn)

        reset_mem_btn = QPushButton("Reset to Default")
        reset_mem_btn.clicked.connect(lambda: self.memory_edit.setPlainText(memory_manager.DEFAULT_MEMORY))
        mem_btn_row.addWidget(reset_mem_btn)

        mem_layout.addLayout(mem_btn_row)
        tabs.addTab(mem_tab, "Memory")

        # Buttons
        btn_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        btn_box.accepted.connect(self._save)
        btn_box.rejected.connect(self.reject)
        btn_box.setStyleSheet(STYLESHEET)
        layout.addWidget(btn_box)

    def _save(self):
        api_key = self.api_key_edit.text().strip()
        if not api_key:
            QMessageBox.warning(self, "Warning", "API key cannot be empty.")
            return
        config.set("api_key", api_key)
        config.set("model", self.model_combo.currentData())
        config.set("max_tokens", self.max_tokens_spin.value())
        config.set("temperature", self.temp_spin.value())
        config.set("system_prompt", self.system_prompt_edit.toPlainText())
        memory_manager.save(self.memory_edit.toPlainText())
        self.accept()

    def _auto_update_memory(self):
        """Call Flash Lite to summarise the current session and update memory."""
        if not GEMINI_AVAILABLE:
            QMessageBox.warning(self, "Error", "google-genai package not installed.")
            return
        api_key = self.api_key_edit.text().strip()
        if not api_key:
            QMessageBox.warning(self, "Error", "Enter your API key first.")
            return
        # Get conversation from parent if available
        conversation = []
        parent = self.parent()
        if hasattr(parent, 'chat_panel'):
            conversation = parent.chat_panel.conversation
        elif hasattr(parent, 'conversation'):
            conversation = parent.conversation
        if not conversation:
            QMessageBox.information(self, "No Session", "No conversation to summarise yet.")
            return

        # Build summary prompt
        convo_text = "\n".join(
            f"{m['role'].upper()}: {m['content'] if isinstance(m['content'], str) else '[attached content]'}"
            for m in conversation[-20:]  # last 20 messages
        )
        prompt = (
            "Summarise this coding session into concise memory notes for an AI assistant. "
            "Extract: coding style preferences, languages used, project context, key decisions, "
            "and anything the assistant should remember in future sessions. "
            "Format as brief markdown bullet points under appropriate headings. "
            "Be very concise — every word costs tokens on every future request.\n\n"
            f"SESSION:\n{convo_text}"
        )

        try:
            client = genai.Client(api_key=api_key)
            resp = client.models.generate_content(
                model="gemini-2.5-flash-lite",
                contents=prompt,
                config=types.GenerateContentConfig(max_output_tokens=512),
            )
            new_memory = (resp.text or "").strip()
            existing = self.memory_edit.toPlainText().strip()
            if existing:
                combined = f"{existing}\n\n## Auto-Updated {datetime.now().strftime('%Y-%m-%d')}\n{new_memory}"
            else:
                combined = f"# Gemini of Death — Persistent Memory\n\n## Auto-Updated {datetime.now().strftime('%Y-%m-%d')}\n{new_memory}"
            self.memory_edit.setPlainText(combined)
            QMessageBox.information(self, "Memory Updated", "Memory updated from current session.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to update memory:\n{str(e)}")

# =============================================================================
# File Attachment Support
# =============================================================================

IMAGE_TYPES = {".png", ".jpg", ".jpeg", ".gif", ".webp"}
TEXT_TYPES   = {".py", ".js", ".ts", ".jsx", ".tsx", ".html", ".css", ".json",
                ".xml", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".sh", ".bash",
                ".zsh", ".fish", ".c", ".cpp", ".h", ".hpp", ".cs", ".java",
                ".go", ".rs", ".rb", ".php", ".swift", ".kt", ".scala", ".r",
                ".sql", ".md", ".txt", ".log", ".env", ".gitignore", ".dockerfile",
                "dockerfile", ".makefile", "makefile", ".bat", ".ps1"}

def classify_file(path: Path) -> str:
    """Returns 'image', 'text', or 'binary'."""
    suffix = path.suffix.lower()
    if suffix in IMAGE_TYPES:
        return "image"
    if suffix in TEXT_TYPES or suffix == "":
        return "text"
    # Try reading as text
    try:
        path.read_text(encoding="utf-8")
        return "text"
    except Exception:
        return "binary"


class FileChip(QWidget):
    """A small removable chip showing an attached file."""
    removed = pyqtSignal(object)  # emits self

    def __init__(self, path: Path, parent=None):
        super().__init__(parent)
        self.path = path
        self.kind = classify_file(path)
        self._setup_ui()

    def _setup_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(6, 3, 4, 3)
        layout.setSpacing(4)
        self.setStyleSheet(f"""
            FileChip {{
                background-color: {COLORS['bg_mid']};
                border: 1px solid {COLORS['border_bright']};
                border-radius: 2px;
            }}
        """)

        icon = {"image": "🖼", "text": "📄", "binary": "📦"}.get(self.kind, "📄")
        icon_lbl = QLabel(icon)
        icon_lbl.setFixedWidth(16)
        layout.addWidget(icon_lbl)

        name_lbl = QLabel(self.path.name)
        name_lbl.setStyleSheet(f"color: {COLORS['text_primary']}; font-size: 11px;")
        name_lbl.setMaximumWidth(160)
        layout.addWidget(name_lbl)

        rm_btn = QPushButton("✕")
        rm_btn.setFixedSize(16, 16)
        rm_btn.setStyleSheet(f"""
            QPushButton {{
                background: transparent;
                color: {COLORS['text_dim']};
                border: none;
                font-size: 10px;
                padding: 0;
            }}
            QPushButton:hover {{ color: {COLORS['accent']}; }}
        """)
        rm_btn.clicked.connect(lambda: self.removed.emit(self))
        layout.addWidget(rm_btn)

        self.setFixedHeight(26)


# =============================================================================
# Chat Panel
# =============================================================================

class ChatPanel(QWidget):
    session_saved = pyqtSignal()  # emitted after save so sessions panel can refresh
    def __init__(self, parent=None):
        super().__init__(parent)
        self.conversation: list[dict] = []
        self.worker: APIWorker | None = None
        self.current_assistant_widget: MessageWidget | None = None
        self.attached_files: list[Path] = []
        self._total_input_tokens = 0
        self._total_output_tokens = 0
        self._current_session_path: Path | None = None
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Toolbar
        toolbar = QWidget()
        toolbar.setFixedHeight(40)
        toolbar.setStyleSheet(f"background-color: {COLORS['bg_darkest']}; border-bottom: 1px solid {COLORS['border']};")
        tb_layout = QHBoxLayout(toolbar)
        tb_layout.setContentsMargins(10, 0, 10, 0)
        tb_layout.setSpacing(8)

        self.session_label = QLabel("New Session")
        self.session_label.setStyleSheet(f"color: {COLORS['text_primary']}; font-size: 11px;")
        tb_layout.addWidget(self.session_label)
        tb_layout.addStretch()

        prompt_btn = QPushButton("📚 PROMPTS")
        prompt_btn.setFixedHeight(26)
        prompt_btn.setToolTip("Prompt Library")
        prompt_btn.clicked.connect(self._open_prompt_library)
        tb_layout.addWidget(prompt_btn)

        clear_btn = QPushButton("CLEAR")
        clear_btn.setFixedHeight(26)
        clear_btn.setToolTip("Clear conversation")
        clear_btn.clicked.connect(self.clear_conversation)
        tb_layout.addWidget(clear_btn)

        save_btn = QPushButton("SAVE SESSION")
        save_btn.setFixedHeight(26)
        save_btn.setToolTip("Save session")
        save_btn.clicked.connect(self.save_session)
        tb_layout.addWidget(save_btn)

        layout.addWidget(toolbar)

        # Scroll area for messages
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll_area.setStyleSheet(f"background-color: {COLORS['bg_dark']};")

        self.messages_widget = QWidget()
        self.messages_widget.setStyleSheet(f"background-color: {COLORS['bg_dark']};")
        self.messages_layout = QVBoxLayout(self.messages_widget)
        self.messages_layout.setContentsMargins(16, 16, 16, 16)
        self.messages_layout.setSpacing(8)
        self.messages_layout.addStretch()

        self.scroll_area.setWidget(self.messages_widget)
        layout.addWidget(self.scroll_area, 1)

        # Thinking indicator
        self.thinking_bar = QWidget()
        self.thinking_bar.setFixedHeight(28)
        self.thinking_bar.setStyleSheet(f"background-color: {COLORS['bg_darkest']};")
        self.thinking_bar.setVisible(False)
        think_layout = QHBoxLayout(self.thinking_bar)
        think_layout.setContentsMargins(14, 0, 14, 0)
        self.thinking_label = QLabel("☠ Generating...")
        self.thinking_label.setStyleSheet(f"color: {COLORS['accent']}; font-size: 11px;")
        think_layout.addWidget(self.thinking_label)
        think_layout.addStretch()
        self.cancel_btn = QPushButton("✕ CANCEL")
        self.cancel_btn.setFixedHeight(20)
        self.cancel_btn.setStyleSheet(f"""
            QPushButton {{
                background: transparent;
                color: {COLORS['text_dim']};
                border: 1px solid {COLORS['border']};
                font-size: 10px;
                padding: 0 6px;
            }}
            QPushButton:hover {{ color: {COLORS['accent']}; border-color: {COLORS['accent']}; }}
        """)
        self.cancel_btn.clicked.connect(self._cancel_generation)
        think_layout.addWidget(self.cancel_btn)
        layout.addWidget(self.thinking_bar)

        # Input area
        input_container = QWidget()
        input_container.setStyleSheet(f"""
            background-color: {COLORS['bg_darkest']};
            border-top: 1px solid {COLORS['border']};
        """)
        input_layout = QVBoxLayout(input_container)
        input_layout.setContentsMargins(12, 10, 12, 12)
        input_layout.setSpacing(6)

        # Attachment chips bar (hidden when empty)
        self.attach_bar = QWidget()
        self.attach_bar.setVisible(False)
        self.attach_bar.setStyleSheet(f"background: transparent;")
        self.attach_bar_layout = QHBoxLayout(self.attach_bar)
        self.attach_bar_layout.setContentsMargins(0, 0, 0, 0)
        self.attach_bar_layout.setSpacing(4)
        self.attach_bar_layout.addStretch()
        input_layout.addWidget(self.attach_bar)

        self.input_edit = QTextEdit()
        self.input_edit.setPlaceholderText("Ask anything about code...  [Ctrl+Enter to send]")
        self.input_edit.setFixedHeight(100)
        self.input_edit.setFont(QFont("Courier New", 12))
        self.input_edit.setAcceptRichText(False)
        input_layout.addWidget(self.input_edit)

        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)

        self.model_label = QLabel()
        self._update_model_label()
        self.model_label.setStyleSheet(f"color: {COLORS['text_primary']}; font-size: 10px;")
        btn_row.addWidget(self.model_label)

        self.token_label = QLabel("")
        self.token_label.setStyleSheet(f"color: {COLORS['text_secondary']}; font-size: 10px;")
        btn_row.addWidget(self.token_label)

        btn_row.addStretch()

        # Attach button
        self.attach_btn = QPushButton("📎 ATTACH")
        self.attach_btn.setFixedHeight(36)
        self.attach_btn.setToolTip("Attach files (code, text, images)")
        self.attach_btn.clicked.connect(self._attach_files)
        btn_row.addWidget(self.attach_btn)

        self.file_btn = QPushButton("📄 GENERATE FILE")
        self.file_btn.setFixedHeight(36)
        self.file_btn.setToolTip(
            "File Mode — clean context, focused system prompt.\n"
            "Use this to generate a complete file in one shot."
        )
        self.file_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['accent_dim']};
                color: #ffffff;
                border: 1px solid {COLORS['accent']};
                padding: 6px 14px;
                font-family: 'Courier New', Courier, monospace;
                font-size: 12px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {COLORS['accent']};
                border-color: {COLORS['accent_glow']};
            }}
            QPushButton:disabled {{
                background-color: {COLORS['bg_mid']};
                border-color: {COLORS['border']};
                color: {COLORS['text_dim']};
            }}
        """)
        self.file_btn.clicked.connect(self.generate_file)
        btn_row.addWidget(self.file_btn)

        self.send_btn = QPushButton("☠ SEND")
        self.send_btn.setObjectName("send_btn")
        self.send_btn.setFixedHeight(36)
        self.send_btn.clicked.connect(self.send_message)
        btn_row.addWidget(self.send_btn)

        input_layout.addLayout(btn_row)
        layout.addWidget(input_container)

        # Ctrl+Enter shortcut
        send_shortcut = QShortcut(QKeySequence("Ctrl+Return"), self)
        send_shortcut.activated.connect(self.send_message)

    def _load_code_into_input(self, code: str):
        """Load extracted code into the input box, ready to add instructions and generate."""
        current = self.input_edit.toPlainText().strip()
        if current:
            # Append after any existing text
            self.input_edit.setPlainText(current + "\n\n```\n" + code + "\n```\n")
        else:
            self.input_edit.setPlainText("```\n" + code + "\n```\n")
        self.input_edit.setFocus()
        # Scroll input to top so user sees the code
        cursor = self.input_edit.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.Start)
        self.input_edit.setTextCursor(cursor)

    def _open_prompt_library(self):
        dlg = PromptLibraryDialog(self)
        dlg.prompt_selected.connect(self._insert_prompt)
        dlg.exec()

    def _insert_prompt(self, text: str):
        current = self.input_edit.toPlainText().strip()
        if current:
            self.input_edit.setPlainText(current + "\n\n" + text)
        else:
            self.input_edit.setPlainText(text)
        self.input_edit.setFocus()

    def _auto_save_file(self, content: str):
        """After File Mode completes, save just the code — no markdown, no explanation."""
        blocks = extract_code_blocks(content)

        if blocks:
            code = blocks[0]["code"].strip()
            suggested_name = blocks[0]["suggested_name"]
        else:
            code = content.strip()
            suggested_name = "output.py"

        # Default to Desktop so the dialog opens somewhere sensible
        desktop = Path.home() / "Desktop"
        if not desktop.exists():
            desktop = Path.home()
        default_path = str(desktop / suggested_name)

        path, _ = QFileDialog.getSaveFileName(
            self, "Save Generated File",
            default_path,
            "All Files (*)"
        )
        if path:
            try:
                Path(path).write_text(code, encoding="utf-8")
                QMessageBox.information(self, "Saved", f"File saved to:\n{path}")
            except Exception as e:
                QMessageBox.critical(self, "Save Error", str(e))

    def _update_model_label(self):
        model = config.get("model", "gemini-2.5-flash")
        short = model.split("-")[1] if "-" in model else model
        self.model_label.setText(f"MODEL: {model}")

    def _add_message_widget(self, role: str, content: str = "") -> MessageWidget:
        widget = MessageWidget(role, content)
        if role == "assistant":
            widget.use_code.connect(self._load_code_into_input)
        # Insert before the trailing stretch
        count = self.messages_layout.count()
        self.messages_layout.insertWidget(count - 1, widget)
        QTimer.singleShot(50, self._scroll_to_bottom)
        return widget

    def _scroll_to_bottom(self):
        bar = self.scroll_area.verticalScrollBar()
        bar.setValue(bar.maximum())

    def _attach_files(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Attach Files", "",
            "All Files (*);;Images (*.png *.jpg *.jpeg *.gif *.webp);;"
            "Code & Text (*.py *.js *.ts *.html *.css *.json *.md *.txt *.c *.cpp *.h *.rs *.go)"
        )
        for p in paths:
            path = Path(p)
            if path not in self.attached_files:
                self.attached_files.append(path)
                self._add_chip(path)

    def _add_chip(self, path: Path):
        chip = FileChip(path)
        chip.removed.connect(self._remove_chip)
        # Insert before the trailing stretch
        self.attach_bar_layout.insertWidget(self.attach_bar_layout.count() - 1, chip)
        self.attach_bar.setVisible(True)

    def _remove_chip(self, chip: FileChip):
        if chip.path in self.attached_files:
            self.attached_files.remove(chip.path)
        self.attach_bar_layout.removeWidget(chip)
        chip.deleteLater()
        if not self.attached_files:
            self.attach_bar.setVisible(False)

    def _build_content(self, text: str, files: list[Path]) -> list[dict] | str:
        """Build the message content — plain string if no files, list of blocks if files."""
        if not files:
            return text

        blocks = []

        for path in files:
            kind = classify_file(path)
            try:
                if kind == "image":
                    mime = mimetypes.guess_type(str(path))[0] or "image/png"
                    data = base64.standard_b64encode(path.read_bytes()).decode()
                    blocks.append({
                        "type": "image",
                        "source": {"type": "base64", "media_type": mime, "data": data}
                    })
                elif kind == "text":
                    content = path.read_text(encoding="utf-8", errors="replace")
                    blocks.append({
                        "type": "text",
                        "text": f"<file name=\"{path.name}\">\n{content}\n</file>"
                    })
                else:
                    # Binary — send as base64 document block
                    data = base64.standard_b64encode(path.read_bytes()).decode()
                    blocks.append({
                        "type": "text",
                        "text": f"<file name=\"{path.name}\" encoding=\"base64\">\n{data}\n</file>"
                    })
            except Exception as e:
                blocks.append({
                    "type": "text",
                    "text": f"[Could not read {path.name}: {e}]"
                })

        # User's text prompt goes last
        if text:
            blocks.append({"type": "text", "text": text})

        return blocks

    def _display_label_for_files(self, files: list[Path]) -> str:
        if not files:
            return ""
        names = ", ".join(f.name for f in files)
        return f"[Attached: {names}]\n"

    def generate_file(self):
        """File Mode — send only the current prompt with no history and a focused system prompt."""
        if not GEMINI_AVAILABLE:
            QMessageBox.critical(self, "Missing Dependency",
                "The 'google-genai' package is not installed.\n\nRun: pip install google-genai")
            return

        api_key = config.get("api_key", "")
        if not api_key:
            QMessageBox.information(self, "API Key Required",
                "Please set your Gemini API key in Settings (Ctrl+,).")
            return

        if self.worker is not None:
            return

        text = self.input_edit.toPlainText().strip()
        if not text:
            QMessageBox.information(self, "Nothing to Send",
                "Type a description of the file you want generated.")
            return

        files = list(self.attached_files)
        self.input_edit.clear()

        # Clear attachments
        self.attached_files.clear()
        while self.attach_bar_layout.count() > 1:
            item = self.attach_bar_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.attach_bar.setVisible(False)

        # Build content
        api_content = self._build_content(text, files)
        file_label = self._display_label_for_files(files)
        display_text = file_label + (text or "")

        # Add to conversation and UI
        self.conversation.append({"role": "user", "content": api_content})
        self._add_message_widget("user", f"[FILE MODE]\n{display_text}")
        self.current_assistant_widget = self._add_message_widget("assistant", "")
        self.thinking_bar.setVisible(True)
        self.thinking_label.setText("☠ Generating file...")
        self.send_btn.setEnabled(False)
        self.file_btn.setEnabled(False)

        # Single message — no history, dedicated system prompt, max tokens
        self.worker = APIWorker(
            api_key=api_key,
            model=config.get("model", "gemini-2.5-flash"),
            messages=[{"role": "user", "content": api_content}],
            system_prompt=memory_manager.inject(FILE_MODE_SYSTEM_PROMPT),
            max_tokens=32000,
            temperature=0.2,
        )
        self.worker.chunk_received.connect(self._on_chunk)
        self.worker.finished.connect(self._on_finished)
        self.worker.error.connect(self._on_error)
        self.worker.start()

    def send_message(self):
        if not GEMINI_AVAILABLE:
            QMessageBox.critical(self, "Missing Dependency",
                "The 'google-genai' package is not installed.\n\nRun: pip install google-genai")
            return

        api_key = config.get("api_key", "")
        if not api_key:
            QMessageBox.information(self, "API Key Required",
                "Please set your Gemini API key in Settings (Ctrl+,).")
            return

        text = self.input_edit.toPlainText().strip()
        if (not text and not self.attached_files) or self.worker is not None:
            return

        files = list(self.attached_files)
        self.input_edit.clear()

        # Clear attachments
        self.attached_files.clear()
        while self.attach_bar_layout.count() > 1:
            item = self.attach_bar_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.attach_bar.setVisible(False)

        # Build API content (multipart if files present)
        api_content = self._build_content(text, files)

        # Display label (plain text summary for the chat UI)
        file_label = self._display_label_for_files(files)
        display_text = file_label + (text or "")

        # Add user message to conversation and UI
        self.conversation.append({"role": "user", "content": api_content})
        self._add_message_widget("user", display_text)

        # Prepare assistant widget for streaming
        self.current_assistant_widget = self._add_message_widget("assistant", "")
        self.thinking_bar.setVisible(True)
        self.send_btn.setEnabled(False)

        self.worker = APIWorker(
            api_key=api_key,
            model=config.get("model", "gemini-2.5-flash"),
            messages=self.conversation,
            system_prompt=memory_manager.inject(config.get("system_prompt", DEFAULT_SYSTEM_PROMPT)),
            max_tokens=config.get("max_tokens", 16000),
            temperature=config.get("temperature", 0.7),
        )
        self.worker.chunk_received.connect(self._on_chunk)
        self.worker.finished.connect(self._on_finished)
        self.worker.error.connect(self._on_error)
        self.worker.start()

    def _on_chunk(self, text: str):
        if self.current_assistant_widget:
            self.current_assistant_widget.append_content(text)
            self._scroll_to_bottom()

    def _autosave(self):
        """Silently overwrite the rolling autosave file after every response."""
        try:
            AUTOSAVE_FILE.parent.mkdir(parents=True, exist_ok=True)
            data = {
                "timestamp": datetime.now().isoformat(),
                "model": config.get("model", ""),
                "messages": self.conversation,
            }
            AUTOSAVE_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception as e:
            print(f"[Autosave error] {e}")  # visible in terminal, never interrupts user

    def _on_finished(self, input_tok: int, output_tok: int):
        if self.current_assistant_widget:
            content = self.current_assistant_widget.content
            self.conversation.append({"role": "assistant", "content": content})
            self.current_assistant_widget.render_blocks()
        self._total_input_tokens  += input_tok
        self._total_output_tokens += output_tok
        self._update_token_label(input_tok, output_tok)
        # If file mode was running, auto-open the save dialog
        was_file_mode = not self.file_btn.isEnabled()
        self._cleanup_worker()
        self._update_model_label()
        self._autosave()
        if was_file_mode and self.conversation:
            last = self.conversation[-1]
            if isinstance(last.get("content"), str):
                QTimer.singleShot(200, lambda: self._auto_save_file(last["content"]))

    def _update_token_label(self, last_in: int = 0, last_out: int = 0):
        model = config.get("model", "gemini-2.5-flash")
        pricing = TOKEN_PRICING.get(model, {"input": 3.0, "output": 15.0})
        total_cost = (
            self._total_input_tokens  / 1_000_000 * pricing["input"] +
            self._total_output_tokens / 1_000_000 * pricing["output"]
        )
        tok_str = f"  ▏  ↑{self._total_input_tokens:,} ↓{self._total_output_tokens:,} tokens  ≈ ${total_cost:.4f}"
        self.token_label.setText(tok_str)

    def _on_error(self, error: str):
        if self.current_assistant_widget:
            self.current_assistant_widget.set_content(f"[ERROR] {error}")
        self._cleanup_worker()

    def _cleanup_worker(self):
        self.worker = None
        self.current_assistant_widget = None
        self.thinking_bar.setVisible(False)
        self.thinking_label.setText("☠ Generating...")
        self.send_btn.setEnabled(True)
        self.file_btn.setEnabled(True)
        self.input_edit.setFocus()

    def _cancel_generation(self):
        if self.worker:
            self.worker.cancel()
            self.worker.quit()
            self.worker.wait(2000)
        if self.current_assistant_widget:
            self.current_assistant_widget.append_content("\n\n[Cancelled]")
            content = self.current_assistant_widget.content
            self.conversation.append({"role": "assistant", "content": content})
        self._cleanup_worker()
        self._autosave()

    def clear_conversation(self):
        reply = QMessageBox.question(
            self, "Clear Conversation",
            "Clear the current conversation?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.conversation.clear()
            self._total_input_tokens = 0
            self._total_output_tokens = 0
            self._current_session_path = None
            self.token_label.setText("")
            # Remove all message widgets (keep stretch at end)
            while self.messages_layout.count() > 1:
                item = self.messages_layout.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()
            self.session_label.setText("New Session")

    def export_conversation(self):
        """Export the entire conversation as a markdown file."""
        if not self.conversation:
            QMessageBox.information(self, "Nothing to Export", "No conversation yet.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Conversation",
            f"conversation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md",
            "Markdown (*.md);;Text (*.txt);;All Files (*)"
        )
        if not path:
            return
        lines = [f"# {APP_NAME} — Conversation Export\n",
                 f"*Exported: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*\n",
                 f"*Model: {config.get('model', '')}*\n\n---\n"]
        for msg in self.conversation:
            role = "**YOU**" if msg["role"] == "user" else f"**☠ {APP_NAME.upper()}**"
            content = msg["content"] if isinstance(msg["content"], str) else "[attached content]"
            lines.append(f"\n{role}\n\n{content}\n\n---\n")
        try:
            Path(path).write_text("\n".join(lines), encoding="utf-8")
            QMessageBox.information(self, "Exported", f"Conversation saved to:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Export Error", str(e))

    def _generate_title(self) -> str:
        """Ask Gemini for a short session title based on the first user message."""
        try:
            # Grab the first user message text
            first_user = next(
                (m["content"] if isinstance(m["content"], str)
                 else next((b["text"] for b in m["content"] if b.get("type") == "text"), "")
                 for m in self.conversation if m["role"] == "user"),
                ""
            )
            if not first_user:
                return ""
            api_key = config.get("api_key", "")
            if not api_key or not GEMINI_AVAILABLE:
                return ""
            client = genai.Client(api_key=api_key)
            resp = client.models.generate_content(
                model="gemini-2.5-flash-lite",  # fast + cheap for a title
                contents=(
                    f"Summarise this coding question in 4 words or fewer, "
                    f"no punctuation, title case:\n\n{first_user[:300]}"
                ),
                config=types.GenerateContentConfig(max_output_tokens=16),
            )
            title = (resp.text or "").strip().strip('"').strip("'")
            # Sanitise for use as a filename
            title = re.sub(r'[<>:"/\\|?*]', '', title)
            title = re.sub(r'\s+', '_', title)
            return title[:60]
        except Exception:
            return ""

    def save_session(self):
        try:
            SESSIONS_DIR.mkdir(parents=True, exist_ok=True)

            # Overwrite existing
            if self._current_session_path and self._current_session_path.exists():
                path = self._current_session_path
                data = {
                    "timestamp": datetime.now().strftime("%Y%m%d_%H%M%S"),
                    "model": config.get("model", ""),
                    "messages": self.conversation,
                }
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2)
                self.session_label.setText(path.name)
                self.session_saved.emit()
                return

            # New save — write immediately with timestamp name
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            path = SESSIONS_DIR / f"session_{ts}.json"
            data = {
                "timestamp": ts,
                "model": config.get("model", ""),
                "messages": self.conversation,
            }
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
            self._current_session_path = path
            self.session_label.setText(path.name)
            self.session_saved.emit()

            # Try to rename with descriptive title
            try:
                title = self._generate_title()
                if title:
                    new_path = SESSIONS_DIR / f"{ts}_{title}.json"
                    path.rename(new_path)
                    self._current_session_path = new_path
                    self.session_label.setText(new_path.name)
                    self.session_saved.emit()
            except Exception as e:
                print(f"[save_session] title generation failed: {e}")

            QMessageBox.information(self, "Saved", f"Saved to:\n{self._current_session_path}")

        except Exception as e:
            print(f"[save_session] ERROR: {e}")
            QMessageBox.critical(self, "Save Error", str(e))

    def load_session(self, path: Path, is_autosave: bool = False):
        try:
            with open(path) as f:
                data = json.load(f)
            self.conversation = data.get("messages", [])
            # Clear UI
            while self.messages_layout.count() > 1:
                item = self.messages_layout.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()
            # Re-populate
            last_assistant_content = None
            for msg in self.conversation:
                w = self._add_message_widget(msg["role"], msg["content"])
                if msg["role"] == "assistant" and isinstance(msg["content"], str):
                    last_assistant_content = msg["content"]
                    w.render_blocks()
            if is_autosave:
                # Autosave restore — treat as unsaved new session
                self._current_session_path = None
                self.session_label.setText("Restored (unsaved)")
            else:
                self._current_session_path = path
                self.session_label.setText(path.name)
        except Exception as e:
            QMessageBox.critical(self, "Load Error", str(e))

# =============================================================================
# Sessions Panel
# =============================================================================

class SessionsPanel(QWidget):
    session_selected = pyqtSignal(Path)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Header
        header = QWidget()
        header.setFixedHeight(40)
        header.setStyleSheet(f"background-color: {COLORS['bg_darkest']}; border-bottom: 1px solid {COLORS['border']};")
        h_layout = QHBoxLayout(header)
        h_layout.setContentsMargins(10, 0, 10, 0)
        lbl = QLabel("☠ SESSIONS")
        lbl.setFont(QFont("Courier New", 10, QFont.Weight.Bold))
        lbl.setStyleSheet(f"color: {COLORS['accent']};")
        h_layout.addWidget(lbl)
        h_layout.addStretch()
        refresh_btn = QPushButton("↻")
        refresh_btn.setFixedSize(24, 24)
        refresh_btn.clicked.connect(self.refresh)
        h_layout.addWidget(refresh_btn)
        layout.addWidget(header)

        self.list_widget = QListWidget()
        self.list_widget.itemDoubleClicked.connect(self._on_item_double_clicked)
        layout.addWidget(self.list_widget)

        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(4)
        btn_layout.setContentsMargins(4, 4, 4, 4)

        delete_btn = QPushButton("Delete")
        delete_btn.setToolTip("Delete selected session")
        delete_btn.clicked.connect(self._delete_selected)
        btn_layout.addWidget(delete_btn)

        delete_all_btn = QPushButton("Delete All")
        delete_all_btn.setToolTip("Delete all saved sessions")
        delete_all_btn.setStyleSheet(f"""
            QPushButton {{
                background-color: {COLORS['bg_mid']};
                color: {COLORS['accent']};
                border: 1px solid {COLORS['accent_dim']};
                padding: 6px 10px;
                font-family: 'Courier New', Courier, monospace;
                font-size: 12px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {COLORS['accent_dim']};
                border-color: {COLORS['accent']};
                color: #ffffff;
            }}
            QPushButton:pressed {{
                background-color: {COLORS['accent']};
            }}
        """)
        delete_all_btn.clicked.connect(self._delete_all)
        btn_layout.addWidget(delete_all_btn)

        layout.addLayout(btn_layout)

        self.refresh()

    def refresh(self):
        self.list_widget.clear()
        if SESSIONS_DIR.exists():
            sessions = sorted(SESSIONS_DIR.glob("*.json"), reverse=True)
            for s in sessions:
                item = QListWidgetItem(s.name)
                item.setData(Qt.ItemDataRole.UserRole, s)
                self.list_widget.addItem(item)

    def _on_item_double_clicked(self, item):
        path = item.data(Qt.ItemDataRole.UserRole)
        if path:
            self.session_selected.emit(path)

    def _delete_selected(self):
        item = self.list_widget.currentItem()
        if not item:
            return
        path = item.data(Qt.ItemDataRole.UserRole)
        reply = QMessageBox.question(self, "Delete Session", f"Delete {path.name}?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            path.unlink(missing_ok=True)
            self.refresh()

    def _delete_all(self):
        if self.list_widget.count() == 0:
            QMessageBox.information(self, "No Sessions", "There are no saved sessions to delete.")
            return
        count = self.list_widget.count()
        reply = QMessageBox.question(
            self, "Delete All Sessions",
            f"Permanently delete all {count} saved session(s)?\n\nThis cannot be undone.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,   # default to No for safety
        )
        if reply == QMessageBox.StandardButton.Yes:
            if SESSIONS_DIR.exists():
                for f in SESSIONS_DIR.glob("*.json"):
                    f.unlink(missing_ok=True)
            self.refresh()

# =============================================================================
# Main Window
# =============================================================================

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME}  //  {ORG_NAME}")
        self.setMinimumSize(640, 480)
        self.resize(1200, 800)
        self._setup_icon()
        self._setup_ui()
        self._setup_menu()
        self._check_first_run()

    def _setup_icon(self):
        icon_path = Path(__file__).parent / "splash.png"
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))

    def _setup_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        central.setStyleSheet(f"background-color: {COLORS['bg_dark']};")

        main_layout = QHBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # Splitter: sessions | chat
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setHandleWidth(1)
        splitter.setStyleSheet(f"QSplitter::handle {{ background: {COLORS['border']}; }}")

        # Sessions panel
        self.sessions_panel = SessionsPanel()
        self.sessions_panel.setMinimumWidth(180)
        self.sessions_panel.setMaximumWidth(280)
        splitter.addWidget(self.sessions_panel)

        # Chat panel
        self.chat_panel = ChatPanel()
        splitter.addWidget(self.chat_panel)
        splitter.setSizes([220, 980])

        self.sessions_panel.session_selected.connect(self._load_session)
        self.chat_panel.session_saved.connect(self.sessions_panel.refresh)

        main_layout.addWidget(splitter)

        # Status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage(f"  {APP_NAME} v{VERSION}  //  {ORG_NAME}  //  Ready")

    def _setup_menu(self):
        menubar = self.menuBar()

        # File menu
        file_menu = menubar.addMenu("File")
        new_action = file_menu.addAction("New Session")
        new_action.setShortcut("Ctrl+N")
        new_action.triggered.connect(self.chat_panel.clear_conversation)

        save_action = file_menu.addAction("Save Session")
        save_action.setShortcut("Ctrl+S")
        save_action.triggered.connect(self.chat_panel.save_session)

        open_action = file_menu.addAction("Open Session...")
        open_action.setShortcut("Ctrl+O")
        open_action.triggered.connect(self._open_session)

        file_menu.addSeparator()
        export_action = file_menu.addAction("Export Conversation...")
        export_action.setShortcut("Ctrl+E")
        export_action.triggered.connect(self.chat_panel.export_conversation)

        file_menu.addSeparator()
        delete_all_action = file_menu.addAction("Delete All Sessions...")
        delete_all_action.triggered.connect(lambda: self.sessions_panel._delete_all())

        file_menu.addSeparator()
        quit_action = file_menu.addAction("Quit")
        quit_action.setShortcut("Ctrl+Q")
        quit_action.triggered.connect(self.close)

        # Settings menu
        settings_menu = menubar.addMenu("Settings")
        prefs_action = settings_menu.addAction("Preferences...")
        prefs_action.setShortcut("Ctrl+,")
        prefs_action.triggered.connect(self._open_settings)

        # Help menu
        help_menu = menubar.addMenu("Help")
        prompts_action = help_menu.addAction("Prompt Library...")
        prompts_action.setShortcut("Ctrl+P")
        prompts_action.triggered.connect(self.chat_panel._open_prompt_library)
        help_menu.addSeparator()
        about_action = help_menu.addAction("About")
        about_action.triggered.connect(self._show_about)

        api_action = help_menu.addAction("Get API Key...")
        api_action.triggered.connect(lambda: webbrowser.open("https://aistudio.google.com/apikey"))

    def _check_first_run(self):
        if not config.get("api_key"):
            QTimer.singleShot(500, self._open_settings)
        else:
            QTimer.singleShot(300, self._offer_autosave_restore)

    def _offer_autosave_restore(self):
        if not AUTOSAVE_FILE.exists():
            return
        try:
            data = json.loads(AUTOSAVE_FILE.read_text(encoding="utf-8"))
            messages = data.get("messages", [])
            ts = data.get("timestamp", "")[:19].replace("T", " ")
            if not messages:
                return
            msg_count = len(messages)
            reply = QMessageBox.question(
                self,
                "Restore Autosave?",
                f"An autosaved session was found:\n\n"
                f"  {msg_count} messages  ·  {ts}\n\n"
                f"Restore it?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes,
            )
            if reply == QMessageBox.StandardButton.Yes:
                self.chat_panel.load_session(AUTOSAVE_FILE, is_autosave=True)
                self.status_bar.showMessage("Autosave restored.", 4000)
        except Exception:
            pass

    def _open_settings(self):
        dlg = SettingsDialog(self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.chat_panel._update_model_label()
            self.status_bar.showMessage("Settings saved.", 3000)

    def _open_session(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Session", str(SESSIONS_DIR), "JSON Files (*.json)"
        )
        if path:
            self._load_session(Path(path))

    def _load_session(self, path: Path):
        self.chat_panel.load_session(path)
        self.sessions_panel.refresh()

    def _show_about(self):
        QMessageBox.information(self, f"About {APP_NAME}",
            f"{APP_NAME} v{VERSION}\n"
            f"{ORG_NAME}\n\n"
            "An AI-powered coding assistant built on\n"
            "the Google Gemini API.\n\n"
            "Users supply their own API key.\n"
            "Billing is directly with Google.")

# =============================================================================
# Entry Point
# =============================================================================

def main():
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                f"DeathsHeadSoftware.{APP_NAME.replace(' ', '')}.1"
            )
        except Exception:
            pass

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    app.setStyleSheet(STYLESHEET)

    # Set dark palette
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor(17, 17, 17))
    palette.setColor(QPalette.ColorRole.WindowText, QColor(232, 232, 232))
    palette.setColor(QPalette.ColorRole.Base, QColor(10, 10, 10))
    palette.setColor(QPalette.ColorRole.AlternateBase, QColor(20, 20, 20))
    palette.setColor(QPalette.ColorRole.Text, QColor(232, 232, 232))
    palette.setColor(QPalette.ColorRole.Button, QColor(26, 26, 26))
    palette.setColor(QPalette.ColorRole.ButtonText, QColor(232, 232, 232))
    palette.setColor(QPalette.ColorRole.Highlight, QColor(122, 10, 28))
    palette.setColor(QPalette.ColorRole.HighlightedText, QColor(255, 255, 255))
    app.setPalette(palette)

    # Splash
    splash = create_splash()
    if splash:
        splash.show()
        messages = ["Initializing...", "Loading UI...", "Connecting systems...", "Ready."]
        for msg in messages:
            splash.showMessage(
                "\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255)
            )
            app.processEvents()
            time.sleep(0.3)

    window = MainWindow()
    window.show()

    if splash:
        splash.finish(window)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
